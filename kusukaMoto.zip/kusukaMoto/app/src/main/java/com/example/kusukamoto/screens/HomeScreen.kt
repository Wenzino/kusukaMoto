package com.example.kusukamoto.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.kusukamoto.R

@Composable
fun HomeScreen(navController: NavHostController) {
    val selectedServices = remember { mutableStateOf(setOf<String>()) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5)) // Fundo da tela
    ) {
        // Fundo circular no topo
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)  // Altura do c?rculo de fundo
                .align(Alignment.TopCenter)
        ) {
            drawCircle(
                color = Color(0xFF00E0C6),  // Cor do c?rculo
                radius = size.width * 1.5f,  // Ajuste para cobrir a largura
                center = Offset(x = size.width / 2, y = -size.width / 0.95f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            // Se??o Superior com ?cone de notifica??o e avatar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.notification),
                    contentDescription = "Notification Icon",
                    tint = Color(0xFF142D55),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.weight(1f))
                Image(
                    painter = painterResource(id = R.drawable.usericon),
                    contentDescription = "User Avatar",
                    modifier = Modifier
                        .size(50.dp)  // Tamanho ajustado para o avatar
                        .background(Color(0xFFFFCC33), shape = CircleShape)  // Cor do background ajustada
                        .padding(8.dp)
                )
            }

            // Sauda??o do usu?rio
            Text(
                text = "Ol?,\n\"Wen Xuan\"",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF142D55),
                textAlign = TextAlign.Start, // Alinhado ? esquerda
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )

            // Texto dos servi?os
            Text(
                text = "Os nossos servi?os\nMarque o/os servi?o/s pretendido/s",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF142D55),
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp, bottom = 16.dp)  // Ajuste para o espa?amento correto
            )

            // Grid dos servi?os
            val services = listOf(
                "Lavagem Externa" to R.drawable.exterior,
                "Lavagem Interna" to R.drawable.interna,
                "Lavagem Detalhada" to R.drawable.detalhada,
                "Polimento e Enceramento" to R.drawable.polimento,
                "Limpeza de Estofados e Carpetes" to R.drawable.carpete,
                "Lavagem de Motor" to R.drawable.motor
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                for (i in services.indices step 2) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ServiceOption(
                            serviceName = services[i].first,
                            iconResId = services[i].second,
                            selectedServices = selectedServices.value,
                            onSelect = { selectedService ->
                                selectedServices.value = selectedServices.value.toMutableSet().apply {
                                    if (contains(selectedService)) remove(selectedService)
                                    else add(selectedService)
                                }
                            },
                            onInfoClick = { serviceName ->
                                navController.navigate("serviceInfo/$serviceName")
                            }
                        )
                        if (i + 1 < services.size) {
                            ServiceOption(
                                serviceName = services[i + 1].first,
                                iconResId = services[i + 1].second,
                                selectedServices = selectedServices.value,
                                onSelect = { selectedService ->
                                    selectedServices.value = selectedServices.value.toMutableSet().apply {
                                        if (contains(selectedService)) remove(selectedService)
                                        else add(selectedService)
                                    }
                                },
                                onInfoClick = { serviceName ->
                                    navController.navigate("serviceInfo/$serviceName")
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Bot?o 'Avan?ar'
            Button(
                onClick = { /* A??o do bot?o */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E0C6)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(60.dp)
            ) {
                Text(
                    text = "Avan?ar",
                    fontSize = 20.sp,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun ServiceOption(
    serviceName: String,
    iconResId: Int,
    selectedServices: Set<String>,
    onSelect: (String) -> Unit,
    onInfoClick: (String) -> Unit
) {
    val isSelected = selectedServices.contains(serviceName)

    Box(
        modifier = Modifier
            .size(140.dp)  // Tamanho ajustado para se parecer mais com o design
            .background(
                color = if (isSelected) Color(0xFFB3E5FC) else Color(0xFFE1F5FE),
                shape = RoundedCornerShape(12.dp)
            )
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
                .clickable { onSelect(serviceName) }  // Clique para selecionar
        ) {
            Icon(
                painter = painterResource(id = iconResId),
                contentDescription = serviceName,
                tint = Color.Black,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = serviceName,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                color = Color(0xFF142D55)
            )
            Spacer(modifier = Modifier.height(4.dp))
            if (isSelected) {
                Icon(
                    painter = painterResource(id = R.drawable.tick),
                    contentDescription = "Selected",
                    tint = Color(0xFF142D55),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        // Bot?o de informa??es posicionado no canto superior esquerdo
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .size(40.dp)  // Ajusta o tamanho do c?rculo
                .padding(4.dp)
                .background(Color(0xFF142D55), shape = CircleShape)
                .clickable { onInfoClick(serviceName) },  // Clique para navegar
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "i",
                color = Color.White,
                fontSize = 20.sp,  // Ajusta o tamanho da fonte
                fontWeight = FontWeight.Bold
            )
        }
    }
}

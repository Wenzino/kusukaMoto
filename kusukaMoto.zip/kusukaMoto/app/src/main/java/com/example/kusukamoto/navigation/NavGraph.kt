package com.example.kusukamoto.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.kusukamoto.screens.*

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "welcome") {
        composable("welcome") { WelcomeScreen(navController) }
        composable("login") { LoginScreen(navController) }
//        composable("create_account") { CreateAccountScreen(navController) }
        composable("home") { HomeScreen(navController) }
        composable("serviceInfo/{serviceName}") { backStackEntry ->
            val serviceName = backStackEntry.arguments?.getString("serviceName")
            ServiceInfoScreen(serviceName)
        }
    }
}

